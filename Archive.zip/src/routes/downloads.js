
const { downloader } = require('../controllers/downloaders/downloaders');

module.exports = downloader;